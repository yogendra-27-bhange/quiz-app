import database
import gui

if __name__ == '__main__':
    database.create_tables()
    gui
