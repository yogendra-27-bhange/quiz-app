# Advanced Quiz Application

This is a feature-rich Quiz Application built with Python.  
It supports user registration/login, multiple quiz categories and difficulty levels, timed questions, and an admin panel for quiz management.

## Features
- User authentication with password hashing
- Multiple categories and difficulty levels
- Timed questions with timer
- Score calculation and leaderboard
- Admin panel to add/edit/delete questions
- Data persistence using SQLite database
- Basic Tkinter GUI for user-friendly interface

## How to Run
1. Install dependencies:  
pip install -r requirements.txt
2. Initialize the database:  

3. Run the main app:  